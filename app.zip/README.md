# PortDeck

Оболочка-лаунчер для своих «портов» на Android: список игр, у каждого профиля —
эмулятор, пакет, способ запуска и заметки с настройками. Никакого Wine внутри —
PortDeck только аккуратно запускает то, что уже установлено (GameNative, Winlator,
любой другой лаунчер).

Написано под Xiaomi 11T (Dimensity 1200 / Mali-G77), но работает на любом Android 7+.

## Что умеет

- Профили игр: название, пакет эмулятора, подпись, заметки.
- Три способа запуска: открыть приложение, Intent с extras, URI.
- Автопоиск установленных эмуляторов (Winlator, GameNative, Box64, Mobox, Termux…).
- Выбор любого установленного приложения из списка.
- Генератор `adb`-команды — чтобы подбирать extras, не пересобирая приложение.
- Экран «Устройство»: SoC, RAM, ABI, версия OpenGL ES.

## Как собрать APK без компьютера

Есть два пути. Первый — без установки чего-либо, второй — если веб-загрузка папки
на телефоне бесит.

### Путь A: залить через GitHub в браузере

1. Зарегистрируй GitHub (если нет).
2. Создай новый **приватный** репозиторий, например `PortDeck`.
3. Залей туда **содержимое** папки `Download/PortDeck`: `settings.gradle.kts`,
   `build.gradle.kts`, `gradle.properties`, `README.md`, папки `app` и `.github`
   должны лежать в корне репозитория, а не внутри вложенной папки.
4. Открой вкладку **Actions** → workflow **Build APK** → **Run workflow**.
5. Через 3–5 минут зайди в завершённый запуск, внизу раздел **Artifacts** →
   скачай `PortDeck-apk.zip`, распакуй, установи APK.

### Путь B: через Termux (быстрее и надёжнее)

```bash
pkg install git -y
termux-setup-storage
git clone https://github.com/ТВОЙ_НИК/PortDeck.git
cp -r /sdcard/Download/PortDeck/. ~/PortDeck/
cd ~/PortDeck
git add . && git commit -m "init" && git push
```

Вместо пароля GitHub попросит токен: Settings → Developer settings →
Personal access tokens → Tokens (classic) → scope `repo`. После `git push`
дальше всё то же — Actions → Artifacts.

APK подписан debug-ключом. Android может ругаться «неизвестный источник» —
разреши установку для браузера/проводника.

## Как настроить профиль

Открой профиль (долгое нажатие на карточку) и заполни:

| Поле | Что писать |
|---|---|
| Название | `Risk of Rain 2` |
| Пакет эмулятора | `app.gamenative` или `com.winlator` |
| Способ запуска | `Приложение` — просто открыть эмулятор |
| Заметки | свои настройки, чтобы не забыть |

Режим **Extras** нужен, если хочется прыгнуть сразу в игру, минуя меню эмулятора.
Формат — по строке на параметр:

```
# комментарий
i:container_id=1
s:shortcut_path=/home/xuser/.local/share/applications/ror2.desktop
b:fullscreen=true
```

Типы: `s` строка, `i` int, `l` long, `f` float, `b` bool. Без префикса — строка.

Точные имена extras у Winlator/GameNative меняются от версии к версии. Поэтому есть
кнопка **Показать adb-команду**: собери её в приложении, выполни через adb на ПК
(`adb shell am start ...`) и смотри в `adb logcat`, что эмулятор принял. Нашёл
рабочие параметры — вписал в профиль.

## Реальность про RoR2

Risk of Rain 2 — Unity 2019, x86_64, тяжёлые постэффекты. На Mali-G77 через
Wine + Box64 реальный потолок — 15–25 fps при 640x360, и то если запустится.
DXVK требует Vulkan-драйвер уровня Turnip, а он есть только на Adreno.
Старые игры (Warcraft 3, Postal 2, Half-Life 2) на этом железе идут нормально —
для них PortDeck и делался.

## Структура

```
settings.gradle.kts        корневой конфиг Gradle
build.gradle.kts           версии плагинов
app/build.gradle.kts       модуль приложения
app/src/main/java/com/narezany/portdeck/
  MainActivity.kt          UI на Compose
  Model.kt                 профили + хранение (SharedPreferences/JSON)
  Launcher.kt              сборка Intent, extras, adb-команда
  Apps.kt                  список приложений, автопоиск, инфо об устройстве
.github/workflows/build.yml сборка APK в облаке
```

## Права и честность

PortDeck сам ничего не запускает и не содержит игр. Игра должна быть куплена, а
эмулятор — установлен отдельно. Порт чужой игры «с нуля» без исходников невозможен:
сцены Unity обратно не разбираются, а шейдеры скомпилированы под Direct3D.
