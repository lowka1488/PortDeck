package com.narezany.portdeck

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs

data class InstalledApp(val label: String, val packageName: String)

object Apps {

    /** Все приложения, которые можно запустить с рабочего стола. */
    fun launchable(ctx: Context): List<InstalledApp> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val result = ArrayList<InstalledApp>()
        val seen = HashSet<String>()
        try {
            pm.queryIntentActivities(intent, 0).forEach { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@forEach
                if (!seen.add(pkg)) return@forEach
                val label = ri.loadLabel(pm)?.toString() ?: pkg
                result.add(InstalledApp(label, pkg))
            }
        } catch (_: Throwable) {
        }
        return result.sortedBy { it.label.lowercase() }
    }

    /** Ключевые слова, по которым узнаём эмуляторы/лаунчеры Windows-игр. */
    private val EMULATOR_HINTS = listOf(
        "winlator", "gamenative", "game native", "box64", "mobox", "exagear",
        "termux", "pluvia", "gamehub", "cassia", "wine", "vortek"
    )

    fun detectEmulators(ctx: Context): List<InstalledApp> =
        launchable(ctx).filter { app ->
            val haystack = (app.label + " " + app.packageName).lowercase()
            EMULATOR_HINTS.any { haystack.contains(it) }
        }

    fun appLabel(ctx: Context, pkg: String): String? = try {
        val ai: ApplicationInfo = ctx.packageManager.getApplicationInfo(pkg, 0)
        ctx.packageManager.getApplicationLabel(ai).toString()
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }
}

object DeviceInfo {

    fun rows(ctx: Context): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        out.add("Модель" to "${Build.MANUFACTURER} ${Build.MODEL}")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            out.add("SoC" to (Build.SOC_MODEL ?: Build.HARDWARE))
        } else {
            out.add("SoC" to Build.HARDWARE)
        }
        out.add("Ядер CPU" to Runtime.getRuntime().availableProcessors().toString())
        out.add("ABI" to Build.SUPPORTED_ABIS.joinToString(", "))
        out.add(
            "RAM" to
                "${fmtGb(mi.totalMem)} ГБ всего / ${fmtGb(mi.availMem)} ГБ свободно"
        )
        out.add("Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        runCatching {
            val gl = am.deviceConfigurationInfo.glEsVersion
            out.add("OpenGL ES" to gl)
        }
        runCatching {
            val st = StatFs(Environment.getDataDirectory().path)
            out.add("Свободно в /data" to fmtGb(st.availableBytes) + " ГБ")
        }
        out.add("Пакет приложения" to ctx.packageName)
        return out
    }

    private fun fmtGb(bytes: Long): String =
        String.format("%.1f", bytes / 1024.0 / 1024.0 / 1024.0)
}
