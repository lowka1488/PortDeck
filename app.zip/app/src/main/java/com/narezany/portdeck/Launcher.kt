package com.narezany.portdeck

import android.content.Context
import android.content.Intent
import android.net.Uri

data class Extra(val type: Char, val key: String, val value: String)

object Launcher {

    /** Разбирает строку вида "s:container_id=1" (по строке на extra).
     *  Типы: s — строка, i — int, l — long, f — float, b — bool.
     *  Без префикса считается строка. '#" — комментарий. */
    fun parseExtras(text: String): List<Extra> {
        val out = ArrayList<Extra>()
        text.lines().forEach { rawLine ->
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEach
            val hasType = line.length > 1 && line[1] == ':'
            val type = if (hasType) line[0].lowercaseChar() else 's'
            val body = if (hasType) line.substring(2) else line
            val key = body.substringBefore('=').trim()
            if (key.isEmpty()) return@forEach
            val value = if (body.contains('=')) body.substringAfter('=') else ""
            out.add(Extra(type, key, value))
        }
        return out
    }

    private fun applyExtras(intent: Intent, extras: String) {
        parseExtras(extras).forEach { e ->
            when (e.type) {
                'i' -> e.value.trim().toIntOrNull()?.let { intent.putExtra(e.key, it) }
                'l' -> e.value.trim().toLongOrNull()?.let { intent.putExtra(e.key, it) }
                'f' -> e.value.trim().toFloatOrNull()?.let { intent.putExtra(e.key, it) }
                'b' -> intent.putExtra(e.key, e.value.trim().equals("true", ignoreCase = true))
                else -> intent.putExtra(e.key, e.value)
            }
        }
    }

    /** Возвращает null при успехе, иначе текст ошибки. */
    fun launch(ctx: Context, p: Profile): String? {
        val pm = ctx.packageManager
        return try {
            val intent: Intent = when (p.mode) {
                LaunchMode.URI -> {
                    if (p.uri.isBlank()) return "Пустая ссылка в профиле"
                    Intent(Intent.ACTION_VIEW, Uri.parse(p.uri.trim()))
                }

                LaunchMode.EXTRAS -> {
                    val base = if (p.activity.isNotBlank()) {
                        Intent().setClassName(p.packageName, p.activity.trim())
                    } else {
                        pm.getLaunchIntentForPackage(p.packageName)
                            ?: return "Приложение «${p.packageName}» не найдено"
                    }
                    applyExtras(base, p.extras)
                    base
                }

                LaunchMode.APP -> {
                    if (p.packageName.isBlank()) return "В профиле не указан пакет эмулятора"
                    pm.getLaunchIntentForPackage(p.packageName)
                        ?: return "Приложение «${p.packageName}» не установлено"
                }
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            null
        } catch (t: Throwable) {
            t.message ?: t.javaClass.simpleName
        }
    }

    /** Команда для проверки запуска через adb — удобно, когда подбираешь extras. */
    fun adbCommand(p: Profile): String {
        val sb = StringBuilder("am start")
        if (p.activity.isNotBlank()) {
            sb.append(" -n ${p.packageName}/${p.activity}")
        } else {
            sb.append(" -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p ${p.packageName}")
        }
        parseExtras(p.extras).forEach { e ->
            val flag = when (e.type) {
                'i' -> "--ei"
                'l' -> "--el"
                'f' -> "--ef"
                'b' -> "--ez"
                else -> "--es"
            }
            sb.append(" $flag ${e.key} ${e.value}")
        }
        return sb.toString()
    }
}
