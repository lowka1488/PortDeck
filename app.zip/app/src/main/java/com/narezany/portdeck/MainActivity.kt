package com.narezany.portdeck

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ctx = applicationContext
        setContent { PortDeckApp(ctx) }
    }
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF6B3D),
    onPrimary = Color(0xFF16181F),
    secondary = Color(0xFF7FB3FF),
    background = Color(0xFF0B0E14),
    surface = Color(0xFF141822),
    surfaceVariant = Color(0xFF1E2431),
    onSurface = Color(0xFFE8EAF0),
    onSurfaceVariant = Color(0xFFAAB2C2),
    error = Color(0xFFFF5C5C)
)

sealed interface Screen {
    data object List : Screen
    data object Edit : Screen
    data object Picker : Screen
    data object Device : Screen
}

private fun titleFor(screen: Screen): String = when (screen) {
    Screen.List -> "PortDeck"
    Screen.Edit -> "Профиль"
    Screen.Picker -> "Выбор приложения"
    Screen.Device -> "Устройство"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortDeckApp(ctx: Context) {
    var screen by remember { mutableStateOf<Screen>(Screen.List) }
    var profiles by remember { mutableStateOf(Store.load(ctx)) }
    var draft by remember { mutableStateOf<Profile?>(null) }
    var adbText by remember { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun notify(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun persist(next: List<Profile>) {
        profiles = next
        Store.save(ctx, next)
    }

    fun launchProfile(p: Profile) {
        val err = Launcher.launch(ctx, p)
        notify(err?.let { "Не вышло: $it" } ?: "Запускаю «${p.name}»…")
    }

    MaterialTheme(colorScheme = DarkColors, typography = Typography()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
          Box(Modifier.safeDrawingPadding()) {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    TopAppBar(
                        title = { Text(titleFor(screen), fontWeight = FontWeight.SemiBold) },
                        navigationIcon = {
                            if (screen !is Screen.List) {
                                IconButton(onClick = {
                                    screen = Screen.List
                                    draft = null
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                                }
                            }
                        },
                        actions = {
                            if (screen is Screen.List || screen is Screen.Device) {
                                IconButton(onClick = {
                                    screen = if (screen is Screen.Device) Screen.List else Screen.Device
                                }) {
                                    Icon(Icons.Filled.Info, contentDescription = "Устройство")
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                },
                floatingActionButton = {
                    if (screen is Screen.List) {
                        ExtendedFloatingActionButton(
                            onClick = {
                                draft = Profile()
                                screen = Screen.Edit
                            },
                            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                            text = { Text("Профиль") }
                        )
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (screen) {
                        is Screen.List -> ProfileList(
                            profiles = profiles,
                            onLaunch = { launchProfile(it) },
                            onEdit = {
                                draft = it
                                screen = Screen.Edit
                            },
                            onDelete = { p ->
                                persist(profiles.filterNot { it.id == p.id })
                                notify("Удалено: ${p.name}")
                            },
                            onScan = {
                                val found = Apps.detectEmulators(ctx)
                                if (found.isEmpty()) {
                                    notify("Эмуляторы не найдены — добавь профиль вручную")
                                } else {
                                    val known = profiles.map { it.packageName }.toSet()
                                    val fresh = found.filterNot { known.contains(it.packageName) }
                                    if (fresh.isEmpty()) {
                                        notify("Все найденные уже в списке")
                                    } else {
                                        persist(
                                            profiles + fresh.map {
                                                Profile(
                                                    name = it.label,
                                                    emulator = it.label,
                                                    packageName = it.packageName
                                                )
                                            }
                                        )
                                        notify("Добавлено эмуляторов: ${fresh.size}")
                                    }
                                }
                            },
                            onOpenDevice = { screen = Screen.Device }
                        )

                        is Screen.Edit -> {
                            val d = draft
                            if (d != null) {
                                EditScreen(
                                    draft = d,
                                    onChange = { draft = it },
                                    onPickApp = { screen = Screen.Picker },
                                    onSave = {
                                        val clean = d.copy(name = d.name.ifBlank { "Без названия" })
                                        persist(
                                            profiles.filterNot { it.id == clean.id } + clean
                                        )
                                        draft = null
                                        screen = Screen.List
                                        notify("Сохранено")
                                    },
                                    onDelete = {
                                        persist(profiles.filterNot { it.id == d.id })
                                        draft = null
                                        screen = Screen.List
                                        notify("Удалено")
                                    },
                                    onShowAdb = { adbText = Launcher.adbCommand(d) },
                                    onTest = {
                                        val err = Launcher.launch(ctx, d)
                                        notify(err?.let { "Не вышло: $it" } ?: "Запускаю…")
                                    }
                                )
                            }
                        }

                        is Screen.Picker -> PickerScreen(
                            ctx = ctx,
                            onPick = { app ->
                                draft = draft?.copy(
                                    packageName = app.packageName,
                                    emulator = app.label
                                )
                                screen = Screen.Edit
                            }
                        )

                        is Screen.Device -> DeviceScreen(ctx)
                    }
                }
            }
          }
        }

        val cmd = adbText
        if (cmd != null) {
            AlertDialog(
                onDismissRequest = { adbText = null },
                title = { Text("Команда для adb") },
                text = {
                    SelectionContainer {
                        Text(cmd, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { adbText = null }) { Text("OK") } }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ProfileList(
    profiles: List<Profile>,
    onLaunch: (Profile) -> Unit,
    onEdit: (Profile) -> Unit,
    onDelete: (Profile) -> Unit,
    onScan: () -> Unit,
    onOpenDevice: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onScan, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Refresh, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Эмуляторы", maxLines = 1)
                }
                OutlinedButton(onClick = onOpenDevice, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Info, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Телефон", maxLines = 1)
                }
            }
        }

        if (profiles.isEmpty()) {
            item {
                Text(
                    "Пока пусто. Нажми «Профиль» и добавь игру.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        items(profiles, key = { it.id }) { p ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = { onLaunch(p) },
                            onLongClick = { onEdit(p) }
                        )
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(
                                MaterialTheme.colorScheme.primary,
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            p.name.take(1).uppercase(),
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            p.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1
                        )
                        Text(
                            buildString {
                                append(p.emulator.ifBlank { "эмулятор" })
                                append(" • ")
                                append(p.packageName.ifBlank { "пакет не задан" })
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                    IconButton(onClick = { onEdit(p) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Изменить")
                    }
                    IconButton(onClick = { onDelete(p) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            Text(
                "Тап — запустить. Долгое нажатие — редактировать.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditScreen(
    draft: Profile,
    onChange: (Profile) -> Unit,
    onPickApp: () -> Unit,
    onSave: () -> Unit,
    onDelete: () -> Unit,
    onShowAdb: () -> Unit,
    onTest: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = draft.name,
            onValueChange = { onChange(draft.copy(name = it)) },
            label = { Text("Название игры") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = draft.packageName,
            onValueChange = { onChange(draft.copy(packageName = it.trim())) },
            label = { Text("Пакет эмулятора") },
            placeholder = { Text("app.gamenative") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedButton(onClick = onPickApp, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Search, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Выбрать из установленных")
        }

        OutlinedTextField(
            value = draft.emulator,
            onValueChange = { onChange(draft.copy(emulator = it)) },
            label = { Text("Подпись (необязательно)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Способ запуска", style = MaterialTheme.typography.labelLarge)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
            LaunchMode.entries.forEach { m ->
                FilterChip(
                    selected = draft.mode == m,
                    onClick = { onChange(draft.copy(mode = m)) },
                    label = { Text(m.label, maxLines = 1) }
                )
            }
        }

        if (draft.mode != LaunchMode.APP) {
            OutlinedTextField(
                value = draft.activity,
                onValueChange = { onChange(draft.copy(activity = it.trim())) },
                label = { Text("Activity (пусто — главный экран)") },
                placeholder = { Text("com.winlator.XServerDisplayActivity") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (draft.mode == LaunchMode.EXTRAS) {
            OutlinedTextField(
                value = draft.extras,
                onValueChange = { onChange(draft.copy(extras = it)) },
                label = { Text("Extras (по одному на строку)") },
                placeholder = { Text("i:container_id=1\ns:shortcut_path=/home/xuser/ror2.desktop") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Типы: s — строка, i — int, l — long, f — float, b — bool. " +
                    "Без префикса — строка. Строка с # — комментарий.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = onShowAdb, modifier = Modifier.fillMaxWidth()) {
                Text("Показать adb-команду")
            }
        }

        if (draft.mode == LaunchMode.URI) {
            OutlinedTextField(
                value = draft.uri,
                onValueChange = { onChange(draft.copy(uri = it)) },
                label = { Text("URI") },
                placeholder = { Text("gamenative://launch?app=…") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        OutlinedTextField(
            value = draft.notes,
            onValueChange = { onChange(draft.copy(notes = it)) },
            label = { Text("Заметки и настройки") },
            minLines = 4,
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onSave, modifier = Modifier.weight(1f)) { Text("Сохранить") }
            OutlinedButton(onClick = onTest, modifier = Modifier.weight(1f)) { Text("Проверить") }
        }

        TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
            Text("Удалить профиль", color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun PickerScreen(ctx: Context, onPick: (InstalledApp) -> Unit) {
    val apps by produceState<List<InstalledApp>>(initialValue = emptyList()) {
        value = withContext(Dispatchers.IO) { Apps.launchable(ctx) }
    }
    var query by remember { mutableStateOf("") }

    val shown = remember(apps, query) {
        if (query.isBlank()) apps
        else apps.filter {
            it.label.contains(query, true) || it.packageName.contains(query, true)
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Поиск") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        if (apps.isEmpty()) {
            Text("Загрузка…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(shown) { app ->
                Column(Modifier.fillMaxWidth()) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(app) }
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Text(app.label, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            app.packageName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun DeviceScreen(ctx: Context) {
    val rows = remember { DeviceInfo.rows(ctx) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        rows.forEach { (k, v) ->
            Row(Modifier.fillMaxWidth()) {
                Text(
                    k,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    v,
                    modifier = Modifier.weight(1.4f),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("Что важно для портов", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "DXVK (Vulkan) нормально живёт только на Adreno. На Mali используй " +
                        "VirGL/GL и не жди высокого FPS в тяжёлых играх. " +
                        "Для старых игр (Warcraft 3, Postal 2) это не проблема.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
