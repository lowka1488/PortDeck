package com.narezany.portdeck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class LaunchMode(val label: String) {
    APP("Приложение"),
    EXTRAS("Extras"),
    URI("URI")
}

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val emulator: String = "",
    val packageName: String = "",
    val activity: String = "",
    val mode: LaunchMode = LaunchMode.APP,
    val extras: String = "",
    val uri: String = "",
    val notes: String = ""
)

object Store {
    private const val PREF = "portdeck"
    private const val KEY = "profiles_v1"

    fun load(ctx: Context): List<Profile> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw.isNullOrBlank()) return defaults()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Profile>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Profile(
                        id = o.optString("id", UUID.randomUUID().toString()),
                        name = o.optString("name"),
                        emulator = o.optString("emulator"),
                        packageName = o.optString("packageName"),
                        activity = o.optString("activity"),
                        mode = runCatching {
                            LaunchMode.valueOf(o.optString("mode", LaunchMode.APP.name))
                        }.getOrDefault(LaunchMode.APP),
                        extras = o.optString("extras"),
                        uri = o.optString("uri"),
                        notes = o.optString("notes")
                    )
                )
            }
            if (out.isEmpty()) defaults() else out
        } catch (t: Throwable) {
            defaults()
        }
    }

    fun save(ctx: Context, list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("name", p.name)
                    put("emulator", p.emulator)
                    put("packageName", p.packageName)
                    put("activity", p.activity)
                    put("mode", p.mode.name)
                    put("extras", p.extras)
                    put("uri", p.uri)
                    put("notes", p.notes)
                }
            )
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    private fun defaults(): List<Profile> = listOf(
        Profile(
            name = "Risk of Rain 2",
            emulator = "GameNative",
            packageName = "app.gamenative",
            mode = LaunchMode.APP,
            notes = ROR2_NOTES
        ),
        Profile(
            name = "Warcraft 3",
            emulator = "GameNative",
            packageName = "app.gamenative",
            mode = LaunchMode.APP,
            notes = "Лёгкая игра 2002 года — тут реально 30+ fps.\n" +
                "Разрешение 800x450, VirGL, тени вкл, текстуры высокие."
        ),
        Profile(
            name = "Postal 2",
            emulator = "GameNative",
            packageName = "app.gamenative",
            mode = LaunchMode.APP,
            notes = "Тоже старая и лёгкая. Разрешение 640x360, всё на Low.\n" +
                "Если лагает — выключи дистанцию прорисовки."
        )
    )

    const val ROR2_NOTES =
        "Пресеты под Mali-G77 (Dimensity 1200):\n" +
            "• Рендер: VirGL / GL, не DXVK (DXVK работает только на Adreno)\n" +
            "• Разрешение 640x360, апскейл выключен\n" +
            "• Box64 preset: Performance, не Compatibility\n" +
            "• В игре: всё на Low, тени OFF, bloom/SSAO OFF, resolution scale 50%\n" +
            "• Лимит FPS 30, VSync off\n" +
            "• Перед запуском закрыть всё в фоне, батарея — «не экономить»\n" +
            "• Реальный потолок — 15-25 fps. Упирается в GPU и драйвер Mali."
}
